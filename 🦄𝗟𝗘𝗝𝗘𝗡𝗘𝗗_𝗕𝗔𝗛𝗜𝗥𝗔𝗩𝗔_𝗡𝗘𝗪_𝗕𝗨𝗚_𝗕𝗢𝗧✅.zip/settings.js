 const fs = require("fs");
const chalk = require("chalk")
global.BOT_TOKEN = "8378931838:AAHU903rvcFx77C4tF6k6WplPTpeDLYjfPk"
global.BOT_NAME = "𝗕𝗔𝗛𝗜𝗥𝗔𝗩𝗔 𝗕𝗨𝗚 𝗕𝗢𝗧"
global.OWNER_NAME = "https://t.me/lejened_bahirava"
global.OWNER = ["https://t.me/lejened_bahirava"]
global.DEVELOPER = ["7051769280"]
global.pp = 'https://files.catbox.moe/hvv0fi.jpg'

global.owner = global.owner = ['7051769280']
const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})