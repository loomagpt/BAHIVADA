global.public = true

global.AI_KEY = "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"
global.AI_MODEL = "gpt-4o-mini"

global.ownernomer = "94701475778"
global.dev = ["94701475778","94701475778"]
global.ownername = "LEGEND BAHIRAVA BOT"
global.ytname = "𝗟𝗘𝗝𝗘𝗡𝗘𝗗 𝗕𝗔𝗛𝗜𝗥𝗔𝗩𝗔 𝗕𝗢𝗧"
global.socialm = "GitHub: DGXeon"
global.location = "Egypt, cairo, shopra"

global.ownernumber = '94701475778'
global.ownername = 'LEGEND BAHIRAVA BOT'
global.botname = 'LEJENED BAHIRAVA BOT'
global.devname = '𝗣𝗢⃢𝗪𝗘𝗥 𝗕⃝𝗬 𝗧𝗢⃢𝗫𝗜𝗖'
global.packname = '\n\n\n\n\n\n\nSticker By'
global.author = '𝗕𝗔𝗛𝗜𝗥𝗔𝗩𝗔 𝗕𝗨𝗚 𝗕𝗢𝗧\n\nContact: 94701475778'
global.themeemoji = '🪀'
global.wm = "𝗕𝗔𝗛𝗜𝗥𝗔𝗩𝗔 𝗕𝗨𝗚 𝗕𝗢𝗧."
global.link = 'https://whatsapp.com/channel/0029VbCCnP5CxoAtT7uiXH0D'
global.idch = '120363420097356422@newsletter'

global.baileysDB = 'baileysDB.json'
global.botDb = 'database.json'
global.prefa = ['','!','.',',','🐤','🗿'] 

global.limitawal = {
    premium: "Infinity",
    free: 20
}

global.groupOnlyMsg = '❌ This command can only be used in groups'
module.exports = {
    banner: [
        "923238663852@s.whatsapp.net",
        "20@s.whatsapp.net",
        "923177875465@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net"
    ]
};

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})